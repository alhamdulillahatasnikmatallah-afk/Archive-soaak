package com.nanzmusify.nanas.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.nanzmusify.nanas.data.settings.SettingsRepository
import com.nanzmusify.nanas.ui.theme.NanzMusifyBackground
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextMuted
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import kotlinx.coroutines.launch

@Composable
fun OnboardingScreen(
    settings: SettingsRepository,
    onFinished: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val ageNumber = age.toIntOrNull()
    val valid = name.trim().isNotEmpty() && ageNumber != null && ageNumber in 1..120

    Box(
        Modifier.fillMaxSize().background(NanzMusifyBackground).navigationBarsPadding()
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.size(72.dp),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.MusicNote, null, tint = NanzMusifyTextPrimary, modifier = Modifier.size(52.dp))
            }
            Spacer(Modifier.height(22.dp))
            Text("NanzMusify", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = NanzMusifyTextPrimary)
            Spacer(Modifier.height(8.dp))
            Text("Sebelum mulai, kenalan dulu.", color = NanzMusifyTextMuted)
            Spacer(Modifier.height(30.dp))

            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(24) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Nama") },
                placeholder = { Text("Nama kamu") },
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = age,
                onValueChange = { age = it.filter(Char::isDigit).take(3) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Umur") },
                placeholder = { Text("Contoh: 17") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
            Spacer(Modifier.height(22.dp))
            Text(
                "Data ini digunakan untuk pengaturan pengalaman aplikasi dan disimpan di perangkat.",
                color = NanzMusifyTextMuted,
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(24.dp))
            Button(
                enabled = valid,
                onClick = {
                    scope.launch {
                        settings.completeOnboarding(name, ageNumber!!)
                        onFinished()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color.Black,
                    disabledContainerColor = Color(0xFF2A2A2A),
                    disabledContentColor = Color(0xFF777777),
                ),
            ) {
                Text("Mulai NanzMusify", fontWeight = FontWeight.Bold)
            }
        }
    }
}
