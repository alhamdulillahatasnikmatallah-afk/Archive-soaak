/*
 * Copyright (C) 2026 Nanas
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */
package com.nanzmusify.nanas.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.nanzmusify.nanas.ui.theme.NanzMusifyBackground
import com.nanzmusify.nanas.ui.theme.NanzMusifyCrimson
import com.nanzmusify.nanas.ui.theme.NanzMusifyHairline
import com.nanzmusify.nanas.ui.theme.NanzMusifyRadius
import com.nanzmusify.nanas.ui.theme.NanzMusifySurface
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextMuted
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextPrimary
import com.nanzmusify.nanas.ui.theme.NanzMusifyTextSecondary

/** Nomor WhatsApp developer, format internasional tanpa "+" (dipakai untuk deep link wa.me). */
private const val DEVELOPER_WHATSAPP_NUMBER = "6287881592763"

/**
 * Tab "Profil" — bukan pengaturan lengkap (itu tetap ada, lewat ikon gerigi
 * di kanan atas), tapi papan pengumuman singkat dari developer + formulir
 * laporan bug yang langsung membuka WhatsApp dengan pesan terisi otomatis.
 */
@Composable
fun ProfileScreen(
    onOpenFullSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var bugDescription by rememberSaveable { mutableStateOf("") }
    var reporterName by rememberSaveable { mutableStateOf("") }
    val canSend = bugDescription.isNotBlank() && reporterName.isNotBlank()

    fun sendToWhatsApp() {
        val message = buildString {
            append("Laporan Bug NanzMusify\n\n")
            append("Nama: ").append(reporterName.trim()).append('\n')
            append("Bug: ").append(bugDescription.trim())
        }
        val encoded = Uri.encode(message)
        val waUri = Uri.parse("https://wa.me/$DEVELOPER_WHATSAPP_NUMBER?text=$encoded")
        // Selalu bungkus intent eksternal dengan runCatching — perangkat tanpa
        // browser/WhatsApp sama sekali (sangat jarang) tidak boleh membuat app crash.
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, waUri))
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NanzMusifyBackground)
            .verticalScroll(rememberScrollState())
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 20.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 20.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                "Profil",
                style = MaterialTheme.typography.headlineSmall,
                color = NanzMusifyTextPrimary,
                fontWeight = FontWeight.Bold,
            )
            IconButton(onClick = onOpenFullSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Pengaturan lengkap", tint = NanzMusifyTextSecondary)
            }
        }

        Spacer(Modifier.height(8.dp))

        // ---- Papan pengumuman developer ----
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(NanzMusifyRadius.lg))
                .background(NanzMusifySurface)
                .border(1.dp, NanzMusifyHairline, RoundedCornerShape(NanzMusifyRadius.lg))
                .padding(20.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(NanzMusifyCrimson.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Construction, contentDescription = null, tint = NanzMusifyCrimson)
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    "Dalam tahap pengembangan",
                    style = MaterialTheme.typography.titleMedium,
                    color = NanzMusifyTextPrimary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "APP INI DALAM TAHAP PENGEMBANGAN OLEH NANZZ (SELAKU DEVELOPER) DAN REKAN TIM NYA.",
                style = MaterialTheme.typography.bodyMedium,
                color = NanzMusifyTextSecondary,
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Jika Anda menemukan bug yang bermasalah / mengganggu Anda, Anda dapat melaporkannya ke developer via WhatsApp di nomor +62 878-8159-2763. Sebelum terhubung ke developer, Anda wajib mengisi formulir di bawah.",
                style = MaterialTheme.typography.bodyMedium,
                color = NanzMusifyTextSecondary,
            )
        }

        Spacer(Modifier.height(20.dp))

        // ---- Formulir laporan bug ----
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(NanzMusifyRadius.lg))
                .background(NanzMusifySurface)
                .border(1.dp, NanzMusifyHairline, RoundedCornerShape(NanzMusifyRadius.lg))
                .padding(20.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.BugReport, contentDescription = null, tint = NanzMusifyCrimson, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    "Laporkan bug ke developer",
                    style = MaterialTheme.typography.titleSmall,
                    color = NanzMusifyTextPrimary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Spacer(Modifier.height(16.dp))

            Text("Bug apa yang Anda ketahui:", style = MaterialTheme.typography.labelMedium, color = NanzMusifyTextMuted)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = bugDescription,
                onValueChange = { bugDescription = it },
                placeholder = { Text("Contoh: lagu berhenti sendiri saat...") },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                colors = profileFieldColors(),
            )

            Spacer(Modifier.height(14.dp))

            Text("Siapa nama Anda:", style = MaterialTheme.typography.labelMedium, color = NanzMusifyTextMuted)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = reporterName,
                onValueChange = { reporterName = it },
                placeholder = { Text("Nama Anda") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                colors = profileFieldColors(),
            )

            Spacer(Modifier.height(18.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .background(if (canSend) NanzMusifyCrimson else NanzMusifySurface)
                    .border(1.dp, if (canSend) Color.Transparent else NanzMusifyHairline, RoundedCornerShape(50))
                    .clickable(enabled = canSend) { sendToWhatsApp() }
                    .padding(vertical = 14.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Filled.Send,
                    contentDescription = null,
                    tint = if (canSend) NanzMusifyBackground else NanzMusifyTextMuted,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "Kirim ke WhatsApp Developer",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (canSend) NanzMusifyBackground else NanzMusifyTextMuted,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            if (!canSend) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Isi kedua kolom di atas dulu sebelum mengirim.",
                    style = MaterialTheme.typography.labelSmall,
                    color = NanzMusifyTextMuted,
                )
            }
        }

        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun profileFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = NanzMusifyTextPrimary,
    unfocusedTextColor = NanzMusifyTextPrimary,
    focusedBorderColor = NanzMusifyCrimson,
    unfocusedBorderColor = NanzMusifyHairline,
    cursorColor = NanzMusifyCrimson,
    focusedPlaceholderColor = NanzMusifyTextMuted,
    unfocusedPlaceholderColor = NanzMusifyTextMuted,
)
